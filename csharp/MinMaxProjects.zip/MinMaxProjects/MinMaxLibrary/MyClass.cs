﻿using System;
namespace MinMaxLibrary
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}

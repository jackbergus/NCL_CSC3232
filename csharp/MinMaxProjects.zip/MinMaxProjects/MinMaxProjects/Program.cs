﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace MinMaxProjects {
    class MainClass {
        public static void Main(string[] args)
        {
            //tests.MinMaxABTests.test();
            //tests.MaxNTest.test();
            tests.RealisticTest.test();

            Console.WriteLine("Press a key: ");
            Console.ReadKey();
        }
    }
}

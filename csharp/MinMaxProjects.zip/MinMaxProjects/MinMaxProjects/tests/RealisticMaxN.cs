﻿using System;
namespace MinMaxProjects.tests
{
    public class RealisticMaxN
    {
        public static void test()
        {
        }
    }
}
